Documentation of the Default DOSDP Pipeline
