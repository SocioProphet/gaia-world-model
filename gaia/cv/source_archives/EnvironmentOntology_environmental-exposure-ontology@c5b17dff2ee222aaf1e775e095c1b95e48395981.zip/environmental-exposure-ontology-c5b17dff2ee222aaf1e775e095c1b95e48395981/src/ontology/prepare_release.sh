#!/bin/sh
./run.sh make prepare_release
