#!/bin/sh
./run.sh make test
