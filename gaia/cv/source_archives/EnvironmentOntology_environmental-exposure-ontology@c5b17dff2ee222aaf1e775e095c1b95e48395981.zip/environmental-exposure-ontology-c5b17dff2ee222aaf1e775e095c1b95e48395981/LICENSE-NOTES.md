This ontology is public domain, see [LICENSE.txt](LICENSE.txt). We also include this in the ontology header.

Note that the source for the design patterns is licensed under CC-BY, see [src/patterns/LICENSE.txt](src/patterns/LICENSE.txt)

