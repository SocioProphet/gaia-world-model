A directory for static content such as images used by the guides.
