# Governance #

We will leverage the [Earth Science Information Partners - Science on Schema.org Cluster](http://wiki.esipfed.org/index.php/Schema.org_Cluster) for organizing the cluster. We welcome contributions, which are described in [CONTRIBUTING.md](./CONTRIBUTING.md).

Meetings are scheduled twice monthly:

- When: 
    - 4th Thursday, 2:30pmET
- Where: Telecons via Zoom
    - Connection: https://us02web.zoom.us/j/85680809640?pwd=a09zQTl2eFd6NnpoRkRxNHlDdFN0dz09
    - Meeting ID: 856 8080 9640
    - Passcode: 002196
    - Phone Access: United States: +1 (786) 535-3211
    - Dial by your location (Find your local number: https://us02web.zoom.us/u/kcKljXMoF0)
- [Living Agenda](https://docs.google.com/document/d/1tIlDVnKeocO1E_SSbNaldv0avORfGFdmYDNk_3ub6ik/edit?ts=5d9ed12d)

Suggestions on governance models are welcome!
