# Framing

## About

This directory is where work with the JSON-LD Framing API  (https://json-ld.org/spec/latest/json-ld-framing/) will take place.  Framing could potentially be used as part of a validation 
or extraction process for the data graphs. 