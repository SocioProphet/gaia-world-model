/**
 * 
 */
/**
 * @author cjm
 *
 */
package org.geneontology.obographs.core.io;