/**
 * Advanced Obo Graph model
 * 
 * Represents OWL axioms that do not fit into the Basic Obo Graph model
 * 
 * 
 * @author cjm
 *
 */
package org.geneontology.obographs.core.model.axiom;