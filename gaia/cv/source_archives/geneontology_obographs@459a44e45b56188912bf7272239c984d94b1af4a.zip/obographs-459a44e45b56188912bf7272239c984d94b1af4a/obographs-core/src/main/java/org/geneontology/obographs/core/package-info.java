/**
 * 
 * OBO Graphs
 * 
 * Useful classes:
 * 
 * {@link org.geneontology.obographs.core.model.GraphDocument}
 *
 *
 * @author cjm
 *
 */
package org.geneontology.obographs.core;