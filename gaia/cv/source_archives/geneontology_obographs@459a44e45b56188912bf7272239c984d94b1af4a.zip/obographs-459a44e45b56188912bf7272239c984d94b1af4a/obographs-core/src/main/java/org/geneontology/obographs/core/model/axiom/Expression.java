package org.geneontology.obographs.core.model.axiom;

public interface Expression {

}
