
/**
 * Objects that can be associated with a {@link org.geneontology.obographs.core.model.Meta} holder
 * 
 * @author cjm
 *
 */
package org.geneontology.obographs.core.model.meta;