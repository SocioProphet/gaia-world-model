# JSON Schema for OBO Graphs

The JSON schema is currently automatically derived from the object
model via Jackson annotations.

For Basic OBO Graphs, all properties under "graphs" can be ignored, except for:

 * nodes
 * edges

