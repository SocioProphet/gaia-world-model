/**
 * Mapping OGs to OWL and back
 * 
 * Currently only one direction implemented
 * 
 * <br/>
 * 
 * See <a href="https://github.com/geneontology/obographs/blob/master/README-owlmapping.md">Spec</a>
 * 
 * @author cjm
 *
 */
package org.geneontology.obographs.owlapi;