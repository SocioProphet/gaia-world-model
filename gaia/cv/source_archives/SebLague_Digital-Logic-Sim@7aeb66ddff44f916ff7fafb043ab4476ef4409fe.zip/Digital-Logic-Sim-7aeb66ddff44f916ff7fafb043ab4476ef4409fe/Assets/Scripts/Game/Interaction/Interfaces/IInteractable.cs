namespace DLS.Game
{
	public interface IInteractable
	{
	}
}