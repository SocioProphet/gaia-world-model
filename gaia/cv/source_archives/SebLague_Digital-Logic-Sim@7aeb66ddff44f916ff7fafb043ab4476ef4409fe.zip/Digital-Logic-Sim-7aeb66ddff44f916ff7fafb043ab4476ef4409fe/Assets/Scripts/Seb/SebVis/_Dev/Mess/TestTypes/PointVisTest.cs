using UnityEngine;

public class PointVisTest : MonoBehaviour
{
	public Color Col;
}