using UnityEngine;

public class QuadVisTest : MonoBehaviour
{
	public Color col;

	[Header("Outline settings")]
	public bool outline;

	public float thickness;
}