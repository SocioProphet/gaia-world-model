using UnityEngine;

public class TriangleVisTest : MonoBehaviour
{
	public Vector2 offsetA;
	public Vector2 offsetB;
	public Vector2 offsetC;
	public Color col = Color.white;
}