using UnityEngine;

public class PathVisTest : MonoBehaviour
{
	public float thickness;
	public Color col;

	[Range(0, 1)]
	public float t = 1;
}